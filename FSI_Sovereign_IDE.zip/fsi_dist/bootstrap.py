import os
import sys
from src.devcore.context_core import ContextManager
from src.devcore.supervisor import FSI_Supervisor

def initialize_fsi_engine():
    print("[=================================================]")
    print("[+] Ferrell Synthetic Intelligence (FSI) - Booting...")
    print("[=================================================]")
    
    # Check for the Core Weights (The Mind)
    if not os.path.exists("/home/droid/vitalis_devcore/src/model/tri_head_weights.bin"):
        print("[!] Alert: Core neural weights not found. System is in 'Logic-Only' mode.")
    else:
        print("[+] Core weights detected. Synchronizing Fluidic Memory Manifold...")

    # Initialize the Body (DevCore)
    supervisor = FSI_Supervisor()
    print("[+] DevCore operational. System ready for directives.")
    
    return supervisor

if __name__ == "__main__":
    fsi = initialize_fsi_engine()
    
    # The system is now live. It awaits your command.
    user_input = input("\n[FSI Prompt] >> ")
    if user_input:
        print(fsi.execute_directive(user_input))
