#!/bin/bash
echo "[*] Initializing FSI Sovereign Environment..."
if [ ! -f system_architecture_map.json ]; then
    echo "[!] Error: Manifest missing. Architecture broken."
    exit 1
fi
python3 bootstrap.py
